from django.shortcuts import render , HttpResponse

import json
# Create your views here.


topics=[{"name":"Redis" , "doc":"https://redis.io/","url":"https://cdn4.iconfinder.com/data/icons/redis-2/1451/Untitled-2-512.png" , "desc":"Redis is an open source (BSD licensed), in-memory data structure store, used as a database..." , "key":"1"}]
topics+=[{"name":"Git" ,"doc":"https://git-scm.com/", "url":"https://git-scm.com/images/logos/downloads/Git-Icon-1788C.png" ,"desc": "Git is a free and open source distributed version control system designed to handle everyt..." , "key":"4"}]
topics+=[{"name":"Golang" ,"doc":"https://golang.org/", "url":"https://iconape.com/wp-content/png_logo_vector/golang-gopher.png" , "desc": "Go is an open source programming language that makes it easy to build simple, reliable, an... " ,"key":"2"}]
topics+=[{"name":"Docker" , "doc":"https://www.docker.com/","url":"https://www.docker.com/sites/default/files/d8/styles/role_icon/public/2019-07/Moby-logo.png?itok=sYH_JEaJ" , "desc": "Docker is a software platform for building applications based on containers — small and li... " ,"key":"3"}]
topics+=[{"name":"Postgres" , "doc":"https://www.postgresql.org/","url":"https://upload.wikimedia.org/wikipedia/commons/thumb/2/29/Postgresql_elephant.svg/1200px-Postgresql_elephant.svg.png" , "desc": "PostgreSQL is a powerful, open source object-relational database system .." ,"key":"5"}]


from .utils import read_topics , read_cheats , filter_cheats


def health(request):
    return HttpResponse(json.dumps({"status":"healthy"}))


def get_topics(request ):
    d = request.GET
    arr=[]
    topics = read_topics()
    for i in topics:
        if(d["input"]==""):
            arr.append(i)
            continue
        if(d["input"] in i["name"]):
            arr.append(i)
    return HttpResponse(json.dumps({"status": "healthy","topics":arr}))




def get_cheats(request):
    d = request.GET

    try:
        key = d["key"]
        cheats = read_cheats(key)
    except:
        print("Exception in reading cheats")
        cheats = []

    try:
        search_input = d["input"]
        if(search_input != ""):
            cheats = filter_cheats(cheats, search_input)
    except:
        print("Exception in Filtering cheats")
        cheats = []


    print("Cheats ", cheats)

    return HttpResponse(json.dumps({"status": "healthy", "cheats": cheats}))