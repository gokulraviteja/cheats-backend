from django.apps import AppConfig


class CheatsConfig(AppConfig):
    name = 'cheats'
