
from django.urls import path

from . import views

urlpatterns = [
    path('health', views.health ),
    path('get_topics', views.get_topics),
    path('get_cheats' , views.get_cheats)
]
