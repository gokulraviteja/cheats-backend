

topics = []


def read_config():
    global topics
    f=open("cheats/config.json")
    s=""
    for i in f:
        s+=i
    d=eval(s)
    print(len(d["config"]))
    for i in d["config"]:
        temp={}
        temp["name"]=i["name"]
        temp["key"] = i["key"]
        temp["doc"] = i["doc"]
        temp["url"] = i["url"]
        temp["desc"] = i["desc"]
        temp["cheatsheet"] = i["cheatsheet"]
        topics.append(temp)


def read_topics():
    return topics


def read_cheats(cheatid):
    for i in topics:
        if(i["key"]==cheatid):
            return i["cheatsheet"]
    return []

def filter_cheats(cheats , search_input):
    filtered = []
    for i in cheats:

        p1 = search_input.lower()
        p2 = i["desc"].lower()

        if(p1 in p2):
            filtered.append(i)
    return filtered


if __name__ == '__main__':
    read_config()
    print(read_topics())